-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: k8a703.p.ssafy.io    Database: onu_db
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth`
--

DROP TABLE IF EXISTS `auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth` (
  `auth_id` int NOT NULL AUTO_INCREMENT,
  `user_phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_provider` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_provider_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`auth_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth`
--

LOCK TABLES `auth` WRITE;
/*!40000 ALTER TABLE `auth` DISABLE KEYS */;
INSERT INTO `auth` VALUES (1,NULL,'kakao','1'),(2,NULL,'kakao','2'),(3,NULL,'kakao','3'),(4,NULL,'kakao','4'),(5,NULL,'kakao','5'),(6,NULL,'kakao','6'),(7,NULL,'kakao','7'),(8,NULL,'kakao','8'),(9,NULL,'kakao','9'),(10,NULL,'kakao','10'),(11,NULL,'kakao','11'),(12,NULL,'kakao','12'),(13,NULL,'kakao','13'),(14,NULL,'kakao','14'),(15,NULL,'kakao','15'),(16,NULL,'kakao','16'),(17,NULL,'kakao','17'),(18,NULL,'kakao','18'),(19,NULL,'kakao','19'),(20,NULL,'kakao','20'),(21,NULL,'kakao','21'),(22,NULL,'kakao','22'),(23,NULL,'kakao','23'),(24,NULL,'kakao','24'),(25,NULL,'kakao','25'),(26,NULL,'kakao','26'),(27,NULL,'kakao','27'),(28,NULL,'kakao','28'),(29,NULL,'kakao','29'),(30,NULL,'kakao','30'),(31,NULL,'kakao','del'),(32,NULL,'kakao','2773619053'),(33,'01047411921','kakao','2648266948'),(34,'01086313641','kakao','2625889279'),(35,'01082726303','kakao','del'),(36,NULL,'kakao','2786764557'),(37,NULL,'kakao','del'),(38,'01082726303','kakao','2636360759'),(39,NULL,'kakao','2735077602');
/*!40000 ALTER TABLE `auth` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-19 11:36:56
